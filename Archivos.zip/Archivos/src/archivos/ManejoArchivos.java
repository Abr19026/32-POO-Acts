/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



/**
 *
 * @author Funxb
 */
public class ManejoArchivos {
    public void readFile(File fname) {
        
        try (FileReader fr = new FileReader(fname)){
            int leido;
            while( (leido = fr.read()) != -1) {
                System.out.print((char) leido);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Archivo no existe");
        } catch (IOException ex) {
            System.out.println("Hubo un error en la lectura");
        }
    }
    
    public void writeFile(File fname, String texto) {
        
        try(FileWriter fr = new FileWriter(fname)) {
            fr.write(texto);
        } catch (FileNotFoundException ex) {
            System.out.println("Archivo no existe");
        } catch (IOException ex) {
            System.out.println("Hubo un error en la escritura");
        }
        
    }
    
}
