/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;
import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Funxb
 */
public class RunArchivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        String direccion = "C:\\Users\\Funxb\\Desktop\\archivito.txt";
        String Reemplazo;
        ManejoArchivos man = new ManejoArchivos();
        File archivo = new File(direccion);
        
        //Lee datos anterior
        System.out.println("\nContenidos de " + direccion + ":\n");
        man.readFile(archivo);
        //Pide nuevos datos
        System.out.println("\n\nReemplazar por: ");
        Reemplazo = scan.nextLine();
        System.out.println("\nEscribiendo en archivo " + direccion + "\n");
        man.writeFile(archivo,Reemplazo);
        //Lee archivo otra vez
        System.out.println("\nContenidos de " + direccion + "\n");
        man.readFile(archivo);
        System.out.println("\n");
    }
    
}
