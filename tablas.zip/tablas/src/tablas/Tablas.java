/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablas;
import java.util.Scanner;
/**
 *
 * @author Abraham Ramírez
 */
public class Tablas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num_ini, num_fin, tabla_ini, tabla_fin;
        // TODO code application logic here
        Scanner Scan = new Scanner(System.in);
        System.out.print("Intoduzca la tabla que va a iniciar: ");
        tabla_ini = Scan.nextInt();
        System.out.print("Intoduzca la tabla hasta la que se va a mostrar: ");
        tabla_fin = Scan.nextInt();
        System.out.print("Intoduzca el numero con que comenzará la tabla: ");
        num_ini = Scan.nextInt();
        System.out.print("Intoduzca el numero con que terminará la tabla: ");
        num_fin = Scan.nextInt();
        
        TablaMult tab = new TablaMult(tabla_ini, tabla_fin, num_ini, num_fin);
    }
    
}
