/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablas;

/**
 *
 * @author Abraham Ramírez
 */
public class TablaMult {
    private void tablas(int tbl_ini,int tbl_fin, int num_ini, int num_fin) {
        int tabla,numero;
        
        for(tabla = tbl_ini; tabla <= tbl_fin; tabla++) {
            System.out.println("\nTabla del " + tabla);
            for(numero=num_ini; numero <= num_fin; numero++) {
                System.out.println(tabla + " x " + numero + " = " +tabla*numero);
            }
        }
    }
    
    public TablaMult(int tbl_ini,int tbl_fin, int num_ini, int num_fin) {
        this.tablas(tbl_ini, tbl_fin, num_ini, num_fin);
    }
}
