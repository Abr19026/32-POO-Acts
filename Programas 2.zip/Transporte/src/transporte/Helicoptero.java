/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public class Helicoptero extends Aereo {
    //Constructores

    public Helicoptero(String marca, String modelo, String base) {
        this.marca = marca;
        this.modelo = modelo;
        this.base = base;
    }
    
    //Metodos
    @Override
    protected void despegar() {
        System.out.printf("%s %s Acelerando aspas\n",this.marca,this.modelo);
    }
    
    @Override
    protected void aterrizar() {
        System.out.printf("%s %s Desacelerando aspas\n",this.marca,this.modelo);
    }
}
