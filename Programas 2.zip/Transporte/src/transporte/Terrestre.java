/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public class Terrestre extends Transporte{

    protected int cantidadRuedas;

    @Override
    protected void operar() {
        acelerar();
        frenos();
        reversa();
    }
    
    public void reversa() {
        System.out.printf("%s %s en reversa\n",this.marca,this.modelo);
    }
    
    public void frenos() {
        System.out.printf("%s %s frenando\n",this.marca,this.modelo);
    }
    
    public void acelerar() {
        System.out.printf("%s %s  acelerando\n",this.marca,this.modelo);
    }

    public int getCantidadRuedas() {
        return cantidadRuedas;
    }

    public void setCantidadRuedas(int cantidadRuedas) {
        this.cantidadRuedas = cantidadRuedas;
    }
    
}
