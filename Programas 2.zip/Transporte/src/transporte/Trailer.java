/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public class Trailer extends Terrestre{
    
    private int cantidadCargas;

    public Trailer(String marca, String modelo, int cantidadCargas, int cantidadRuedas) {
            this.marca = marca;
            this.modelo = modelo;
            this.cantidadCargas = cantidadCargas;
            this.cantidadRuedas = cantidadRuedas;
    }

    /**
     * @return the cantidadCargas
     */
    public int getCantidadCargas() {
        return cantidadCargas;
    }

    /**
     * @param cantidadCargas the cantidadCargas to set
     */
    public void setCantidadCargas(int cantidadCargas) {
        this.cantidadCargas = cantidadCargas;
    }
}
