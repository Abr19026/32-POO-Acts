package transporte;


public class Avion extends Aereo{
    
    //Constructores

    public Avion(String marca, String modelo, String base) {
        this.marca = marca;
        this.modelo = modelo;
        this.base = base;
    }
    
    //Metodos
    @Override
    protected void despegar() {
        System.out.printf("%s %s Acelerando---Despegando\n",this.marca,this.modelo);
    }
    
    @Override
    protected void aterrizar() {
        System.out.printf("%s %s Reduciendo altura---Tocando suelo---Frenando\n",this.marca,this.modelo);
    }
}
