package transporte;


public class Tren extends Terrestre{

    private int cantidadVagones;

    public Tren(String marca, String modelo, int cantidadVagones, int cantidadRuedas) {
            this.marca = marca;
            this.modelo = modelo;
            this.cantidadVagones = cantidadVagones;
            this.cantidadRuedas = cantidadRuedas;
    }

    /**
     * @return the cantidadCargas
     */
    public int getCantidadVagones() {
        return cantidadVagones;
    }

    /**
     * @param cantidadCargas the cantidadCargas to set
     */
    public void setCantidadVagones(int cantidadVagones) {
        this.cantidadVagones = cantidadVagones;
    }
    
}
