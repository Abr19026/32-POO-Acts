/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public class Barco extends Maritimo{

    private String tipoBarco;
    
    public Barco(String marca, String modelo, String tipo) {
            this.marca = marca;
            this.modelo = modelo;
            this.tipoBarco = tipo;
    }
    
    @Override
    protected void operar() {
        System.out.printf("%s %s zarpando\n", this.marca, this.modelo);
        
        if(getTipoBarco()=="Pesca") {
            System.out.printf("%s %s Pescando\n",this.marca, this.modelo);
        }
        else {
            if(getTipoBarco()=="Carga") {
                System.out.printf("%s %s carga\n",this.marca, this.modelo);
            }
        }
        
    }

    /**
     * @return the tipoBarco
     */
    public String getTipoBarco() {
        return tipoBarco;
    }

    /**
     * @param tipoBarco the tipoBarco to set
     */
    public void setTipoBarco(String tipoBarco) {
        this.tipoBarco = tipoBarco;
    }
    
}
