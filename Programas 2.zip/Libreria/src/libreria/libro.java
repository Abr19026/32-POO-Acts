
package libreria;

/**
 * @author Abraham Ramírez Moreno 1902627
 */
public class libro {
    private String titulo;
    private String autor;
    private int numLibros;
    private int numPrestados;

    
    public boolean devolucion() {
        boolean devuelto = true;
        if(this.numPrestados == 0) {
            devuelto = false;
        }
        else {
            numPrestados--;
        }
        return devuelto;
    }
    
    public boolean prestar() {
        boolean prestado = true;
        if(this.numPrestados >= this.numLibros) {
            prestado = false;
        }
        else {
            numPrestados++;
        }
        return prestado;
    }
    
    /*
     Constructores
    */
    public libro() {  
    }
    
    public libro(String titulo, String autor, int numLibros, int numPrestados) {  
        this.titulo=titulo;
        this.autor=autor;
        this.numLibros=numLibros;
        this.numPrestados=numPrestados;
        
    }
    
    /**
     * METODOS SETS Y GETS
     */
    public String getTitulo() {
        return titulo;
    }


    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public String getAutor() {
        return autor;
    }


    public void setAutor(String autor) {
        this.autor = autor;
    }


    public int getNumLibros() {
        return numLibros;
    }


    public void setNumLibros(int numLibros) {
        this.numLibros = numLibros;
    }


    public int getNumPrestados() {
        return numPrestados;
    }


    public void setNumPrestados(int numPrestados) {
        this.numPrestados = numPrestados;
    }
    
    @Override
    public String toString() {
        return "Título: " + this.titulo + "\nAutor: " + this.autor + "\nCantidad en existencia: " + this.numLibros + "\nPrestados: " + this.numPrestados;
    }
}
