package libreria;



import java.util.Scanner;
/**
 *
 * @author Abraham Ramírez Moreno 1902627
 */
public class Libreria {

    public static void main(String[] args) {
        String titulo,autor;
        int cantidad, prestados, i;
        Scanner Scanner1 = new Scanner(System.in);
        
        libro libros[];
        libros = new libro[5];
        
        /*
        *   Entradas de datos
        */
        for( i=0 ; i<5 ; i++) {
            
            System.out.println("\nTitulo del libro: ");
            titulo = Scanner1.nextLine();
            System.out.println("\nAutor del libro: ");
            autor = Scanner1.nextLine();
            System.out.println("\nCantidad de ese libro: ");
            cantidad = Scanner1.nextInt();
            Scanner1.nextLine();
            System.out.println("\nCantidad prestada de ese libro: ");
            prestados = Scanner1.nextInt();
            Scanner1.nextLine();

            /*
            * Crea libro con constructor personalizado
            */
            libros[i] = new libro(titulo,autor,cantidad,prestados);
        }

        
        /*
        * Muestra datos del libro
        */
        for( i=0 ; i<5 ; i++) {
            
            System.out.println("\n\n" + libros[i].toString());
            
            if(libros[i].prestar()== false) {
                System.out.printf("\nNo se puede prestar el libro \"" + libros[i].getTitulo() + "\"");
            }
            else {
                System.out.printf("\nPrestamo exitoso de \"" + libros[i].getTitulo() + "\"");
            }
            
            if(libros[i].devolucion()== false) {
                System.out.printf("\nNo hay ejemplares prestados de \"" + libros[i].getTitulo() + "\"");
            }
            else {
                System.out.printf("\nDevolución exitosa de \"" + libros[i].getTitulo() + "\"");
            }
            
        }
    }
    
}
