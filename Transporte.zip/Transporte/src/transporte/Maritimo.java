/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public abstract class Maritimo extends Transporte{
    protected String puertoBase;
    

    //Sets gets puerto base
    public String getPuertoBase() {
        return puertoBase;
    }

    public void setPuertoBase(String puertoBase) {
        this.puertoBase = puertoBase;
    }
}
