package transporte;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Funxb
 */
public class Automovil extends Terrestre{
    
    private int cantidadAsientos;

    public Automovil(String marca, String modelo, int cantidadAsientos) {
            this.marca = marca;
            this.modelo = modelo;
            this.cantidadAsientos = cantidadAsientos;
            this.cantidadRuedas = 4;
    }
    
    public int getCantidadAsientos() {
        return cantidadAsientos;
    }
    
}
