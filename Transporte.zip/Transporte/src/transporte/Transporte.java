package transporte;


public abstract class Transporte {
    
    protected String marca;
    protected String modelo;
    protected boolean encendido;
    
    //Metodos
    public void avanza() {
        if(encendido) {
            operar();
        }
        else {
            System.out.println("Transporte está apagado");
        }
    }
    
    protected abstract void operar();
    
    public void encender() { //Este metodo va a ser igual para todas las subclases
        if(!encendido) {
            encendido = true;
        }
        else {
            System.out.println("Transporte ya estaba encendido");
        }
            
    }
    
    public void apagar() { //Este metodo va a ser igual para todas las subclases
        if(encendido) {
            encendido = false;
        }
        else {
            System.out.println("Transporte ya estaba apagado");
        }
    }

    //Sets y gets

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
}
