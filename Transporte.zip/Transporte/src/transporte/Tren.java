package transporte;


public class Tren extends Terrestre implements ICarga{

    private int cantidadVagones;
    private int cargaLoad;
    
    public Tren(String marca, String modelo, int cantidadVagones, int cantidadRuedas) {
            this.marca = marca;
            this.modelo = modelo;
            this.cantidadVagones = cantidadVagones;
            this.cantidadRuedas = cantidadRuedas;
    }

    /**
     * @return the cantidadCargas
     */
    public int getCantidadVagones() {
        return cantidadVagones;
    }

    /**
     * @param cantidadCargas the cantidadCargas to set
     */
    public void setCantidadVagones(int cantidadVagones) {
        this.cantidadVagones = cantidadVagones;
    }

    @Override
    public void cargar(int carga) {
        System.out.println("Se cargo: " + carga + " a " + this.marca + " " + this.modelo);
        this.cargaLoad=carga;
    }

    @Override
    public int descargar() {
        return this.cargaLoad;
    }
    
}
