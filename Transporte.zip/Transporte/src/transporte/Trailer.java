/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public class Trailer extends Terrestre implements ICarga{
    
    private int cantidadCargas;
    private int cargaLoad;
    
    public Trailer(String marca, String modelo, int cantidadCargas, int cantidadRuedas) {
            this.marca = marca;
            this.modelo = modelo;
            this.cantidadCargas = cantidadCargas;
            this.cantidadRuedas = cantidadRuedas;
    }

    /**
     * @return the cantidadCargas
     */
    public int getCantidadCargas() {
        return cantidadCargas;
    }

    /**
     * @param cantidadCargas the cantidadCargas to set
     */
    public void setCantidadCargas(int cantidadCargas) {
        this.cantidadCargas = cantidadCargas;
    }

    @Override
    public void cargar(int carga) {
        System.out.println("Se cargo: " + carga + " a " + this.marca + " " + this.modelo);
        this.cargaLoad=carga;
    }

    @Override
    public int descargar() {
        return this.cargaLoad;
    }
}
