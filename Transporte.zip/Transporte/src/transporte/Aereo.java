/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public abstract class Aereo extends Transporte{
    
    protected String base;
    
    @Override
    protected void operar() {
        despegar();
        aterrizar();
    }
    
    protected abstract void despegar();
    protected abstract void aterrizar();


    public String getBase() {
        return base;
    }


    public void setBase(String base) {
        this.base = base;
    }
}
