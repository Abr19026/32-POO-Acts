/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;


public class Barco extends Maritimo implements ICarga{

    private String tipoBarco;
    private int cargaLoad=0;
    
    public Barco(String marca, String modelo, String tipo) {
            this.marca = marca;
            this.modelo = modelo;
            this.tipoBarco = tipo;
    }
    
    @Override
    protected void operar() {
        System.out.printf("%s %s zarpando\n", this.marca, this.modelo);
        
        if(getTipoBarco()=="Pesca") {
            System.out.printf("%s %s Pescando\n",this.marca, this.modelo);
        }
        else {
            if(getTipoBarco()=="Carga") {
                System.out.printf("%s %s carga\n",this.marca, this.modelo);
            }
        }
        
    }

    /**
     * @return the tipoBarco
     */
    public String getTipoBarco() {
        return tipoBarco;
    }

    /**
     * @param tipoBarco the tipoBarco to set
     */
    public void setTipoBarco(String tipoBarco) {
        this.tipoBarco = tipoBarco;
    }

    @Override
    public void cargar(int carga) {
        if(tipoBarco == "Carga") {
            this.cargaLoad=carga;
            System.out.println("Se cargo: " + carga + " a " + this.marca + " " + this.modelo);
        }
        else
            System.out.println("Barco no es de carga");
    }

    @Override
    public int descargar() {
        if(tipoBarco != "Carga") {
            System.out.println("Barco no es de carga");
        }
            
        return this.cargaLoad;
    }
    
}
