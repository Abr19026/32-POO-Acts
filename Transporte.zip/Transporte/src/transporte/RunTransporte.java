
package transporte;


/**
 *
 * @author Abraham Ramírez Moreno
 */
public class RunTransporte {

    public static void main(String[] args) {

     //Terrestre
        
        //Carro
        Automovil Carro1 = new Automovil("Mercedez", "LX231",4);
        Carro1.encender();
        Carro1.avanza();
        //Tren
        Tren Tren1= new Tren("Kansas co", "Thomas", 2, 32);
        Tren1.encender();
        Tren1.avanza();
        Tren1.cargar(32);
        System.out.println("Descargando :" + Tren1.descargar());
        //Trailer
        Trailer Tra1 = new Trailer("Volvo","32FB",1,18);
        Tra1.encender();
        Tra1.avanza();
        Tra1.cargar(12);
        System.out.println("Descargando :" + Tra1.descargar());
     //Maritimo
        
        //Barco
        Barco Bar1 = new Barco("HMS", "Titanic", "Carga");
        Bar1.encender();
        Bar1.avanza();
        Bar1.cargar(1972);
        System.out.println("Descargando :" + Bar1.descargar());
     //Aereo
        
        //Avion
        Avion Av1 = new Avion("Boeing","747","MTY");
        Av1.encender();
        Av1.avanza();
        //Helicoptero
        Helicoptero Heli1 = new Helicoptero("HeliUltra","342","LAX");
        Heli1.encender();
        Heli1.avanza();
        
    }
    
}
